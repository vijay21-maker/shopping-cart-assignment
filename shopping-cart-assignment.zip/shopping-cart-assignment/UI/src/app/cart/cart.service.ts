import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public cartApi = 'http://127.0.0.1:5500/shopping-cart-assignment/server/addToCart/index.post.json'

  constructor(private http: HttpClient) { }

  addToCart(): Observable<any> {
    return this.http.get(this.cartApi)
  }
}
