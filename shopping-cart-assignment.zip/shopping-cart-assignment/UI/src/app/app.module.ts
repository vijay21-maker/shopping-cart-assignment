import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ProductsComponent } from './products/products.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from '@angular/router';
import { ProductsService } from './products/products.service';
import { HttpClientModule } from '@angular/common/http';
import { HomeService } from './home/home.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CartService } from './cart/cart.service';
import { RouterTestingModule } from '@angular/router/testing';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CartComponent,
    LoginComponent,
    RegisterComponent,
    ProductsComponent,
    HeaderComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    RouterTestingModule

  ],
  exports: [
    FormsModule, ReactiveFormsModule,
  ],
  providers: [ProductsService, HomeService, CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
