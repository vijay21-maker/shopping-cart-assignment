import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  public bannerApi = 'http://127.0.0.1:5500/shopping-cart-assignment/server/banners/index.get.json';

  public categoriesApi = 'http://127.0.0.1:5500/shopping-cart-assignment/server/categories/index.get.json';

  constructor(private http: HttpClient) { }

  getBanners(): Observable<any> {
    return this.http.get(this.bannerApi);
  }

  getCategories(): Observable<any> {
    return this.http.get(this.categoriesApi);
  }

}
