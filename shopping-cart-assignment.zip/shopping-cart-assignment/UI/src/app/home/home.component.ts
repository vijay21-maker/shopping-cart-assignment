import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public bannersArr: any;
  public categoriesArr: any;
  public bannerId: any;
  public bannersList: any; 

  constructor(private homeService: HomeService) { }

  ngOnInit(): void {

    this.homeService.getBanners().subscribe(
    (response)=>{
      this.bannersArr = response;
      this.bannersList = response;
      console.log(this.bannersArr);
      
    }, 
    (error)=>{
      console.log(error);
    })

    this.homeService.getCategories().subscribe(
      (response)=>{
        this.categoriesArr = response;
        let categories = response.map((element: any, i: any) => {
          if (i%2 == 0) {
            response[i]['flag'] = true;
          }
          else {
            response[i]['flag'] = false;
          }
          return response;
        })
        
        this.categoriesArr = categories[0];
        console.log('categoryArr', this.categoriesArr); 
        
      }, 
      (error)=>{
        console.log(error);
    })
  }

  bannerChecked(id: any) {
    console.log(id);
    let banner;
    for(let i = 0; i< this.bannersArr.length; i++) {
      if (this.bannersArr[i].id == id) {
        banner = this.bannersArr[i];
        console.log(banner);
        this.bannersList = [];
        this.bannersList.push(banner);
      }
    }
    console.log('bannersarray', this.bannersList);
    
  }

}
