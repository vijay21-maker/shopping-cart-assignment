import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public user: any;
  public email: any;
  public password: any;
  public loginForm!: FormGroup;
  public submitted: boolean = false;
  public message: string = "";
  public messageFlag: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router) { }

  

  ngOnInit(): void {

    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
  });

    this.user = localStorage.getItem('registeredUser');
    // let formPassword = localStorage.getItem('formPassword');
    // console.log(formPassword);
    
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
  
    this.submitted = true;
    let userDetails = JSON.parse(this.user);

    console.log(this.user);
    
    console.log(this.loginForm.value.email);
    console.log(userDetails.email);
    console.log(userDetails.password);
    
    


        // stop here if form is invalid
        if (this.loginForm.invalid) {
            return;
        }
        else {
          if (userDetails != null && userDetails != undefined && userDetails.email == this.loginForm.value.email && userDetails.password == this.loginForm.value.password) {
            console.log('Logged in succefully');
            this.router.navigate(['/home'])
            
          }
  
          else {
            console.log('credentials are not same');
            this.messageFlag = true;

            this.message = "New user! please register"
            // this.router.navigate(['/register'])
          }
        }

  }

}
