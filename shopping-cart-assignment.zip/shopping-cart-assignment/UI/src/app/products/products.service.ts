import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  
  public productsApi = 'http://127.0.0.1:5500/shopping-cart-assignment/server/products/index.get.json'
  public categoriesApi = 'http://127.0.0.1:5500/shopping-cart-assignment/server/categories/index.get.json';


  constructor(private http: HttpClient) { }

  getProducts(): Observable<any> {    
    return this.http.get(this.productsApi);
  }

  getCategories(): Observable<any> {
    return this.http.get(this.categoriesApi);
  }
  
}
