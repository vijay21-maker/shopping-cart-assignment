import { Component, OnInit } from '@angular/core';
import { ProductsService } from './products.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  public productsArr: any;
  public categoriesArr: any;
  public selectedProducts: any;
  public isProduct: boolean = false;

  constructor(private productsService: ProductsService) { }

  ngOnInit(): void {    

    this.productsService.getProducts().subscribe(
    (response)=> {
      // console.log("response recieved successfully");
      if (response.length > 0) {
        this.isProduct = true;
      }
      else {
        this.isProduct = false;
      }
      this.productsArr = response;
      console.log(response[0]);
      this.selectedProducts = response;
      
      
    },
    (error)=> {
      console.log(error);
    })

    this.productsService.getCategories().subscribe(
      (response)=> {
        this.categoriesArr = response
      }, 
      (error)=> {
        console.log(error);
        
      })
  }

  public displayCategory(id: any) {
    console.log('id', id);
    this.selectedProducts = this.productsArr.filter((element: any) => {
      // console.log(element.id);
      return element.category == id;
    })
    // console.log(this.selectedProducts);
    if (this.selectedProducts.length > 0) {
      this.isProduct = true;
    }
    else {
      this.isProduct = false;
    }
    
  }

}
